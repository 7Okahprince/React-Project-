# OvisKings Website
This is the official React website project for **OvisKings** (Ovis King'sroyal Energy Services LTD).
- Use Vite to run locally.
- Deploy directly on Vercel or Netlify.
- Branding, contact, services, and domain pre-configured for OvisKings.org.